# SlideSpect moisture backend

The current map can use NASA GIBS directly from the browser. This backend is
a placeholder for the production data service.

Next implementation:
1. Scheduled job checks the newest SMAP L4 data.
2. Download/stream the gridded product.
3. Clip/reproject to the NER bounding box.
4. Validate quality flags and missing cells.
5. Store the newest date and raster metadata.
6. Expose `/api/moisture/latest` and point/raster queries to the frontend.
7. Cache data so the browser does not depend on NASA tile availability.

Do not put NASA Earthdata credentials in frontend JavaScript. If authenticated
data access is needed later, keep credentials on the server.
